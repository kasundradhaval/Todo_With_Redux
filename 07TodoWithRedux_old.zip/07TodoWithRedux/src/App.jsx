import { useEffect, useState } from 'react'
import './App.css'
import TodoForm from './componants/TodoForm'
import TodoItems from './componants/TodoItems'
import Header from './componants/Header'
import { useDispatch, useSelector } from 'react-redux'
import service from './appwrite/auth'
import {login,logout} from './features/AuthSlice'

function App() {
  const todos = useSelector(state => state.todos)
  const [loader, setLoader] = useState(true)
  const dispatch = useDispatch()

  useEffect(()=>{
    service.getAccount()
          .then((userData) => {
            if(userData){
              dispatch(login({userData}))
            }else{
              dispatch(logout())
            }
          })
          .finally(()=> setLoader(false));
  },[])
  

  return !loader ? (
    <div className="bg-[#172842] min-h-screen py-8">
          <div className="mb-4 w-full">
              <Header /> 
          </div>
      <div className="w-full max-w-2xl mx-auto shadow-md rounded-lg px-4 py-3 text-white">
          <h1 className="text-2xl font-bold text-center mb-8 mt-2">Manage Your Todos</h1>
          <div className="mb-4">
              <TodoForm /> 
          </div>
          <div className="flex flex-wrap gap-y-3">
          {todos && todos.length > 0 ? (
            todos.map((todo)=>(
                <div className='w-full'
                key={todo.id}
                >
                  
                <TodoItems todo={todo} />
                </div>
                ))
                ) : (
                  <p className="text-center w-full">No data available!!</p>
                )}
          </div>
      </div>
  </div>
  ) : null
}

export default App
