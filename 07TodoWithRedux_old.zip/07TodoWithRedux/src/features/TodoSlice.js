import { createSlice,nanoid } from "@reduxjs/toolkit";

const getTodosFromLocalStorage = () => {
    const storedTodos = localStorage.getItem("todos");
    return storedTodos ? JSON.parse(storedTodos) : [];
};

const initialState = {
    todos: getTodosFromLocalStorage()
}


export const todoSlice = createSlice({
    name:'todo',
    initialState,
    reducers:{
        addTodo: (state,action) => {
            const todo = {
                id:nanoid(),
                text:action.payload,
                status:false
            }
            state.todos.push(todo)
            localStorage.setItem("todos", JSON.stringify(state.todos))
        },
        removeTodo:(state,action) => {
            state.todos = state.todos.filter((todo)=>todo.id !== action.payload)
            localStorage.setItem("todos", JSON.stringify(state.todos))
        },
        updateTodo: (state,action) => {
            state.todos = state.todos.map((todo) => todo.id == action.payload.id ? {...todo,text:action.payload.text} : todo)
            localStorage.setItem("todos", JSON.stringify(state.todos))
        },
        toggleTodo: (state,action) => {
            state.todos = state.todos.map((todo) => todo.id == action.payload ? {...todo, status:!todo.status} : todo)
            localStorage.setItem("todos", JSON.stringify(state.todos))
        }
    }
})

export const {addTodo,removeTodo,updateTodo,toggleTodo} = todoSlice.actions

export default todoSlice.reducer

